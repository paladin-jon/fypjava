package CAPT;
public class Application{
 
   public static void main(String[] args){
      // Ask our questions
      Answers answers = new Asker().ask();
      
      // Process the results
      Results results = new ResultProcessor().process(answers);
      
      //Save the data
      Database database = new Database();
      database.save(results);
      
      // Fetch the data
      Results resultsFromDatabase = database.fetch();
      
      System.out.println(resultsFromDatabase);
      
    }
  
};

class Answers { 

package java.util.Scanner;

String userInput;

Scanner input = new Scanner(System.in);
userInput = input.nextLine();

// return the variable' value
System.out.print(userInput); 

}

class Asker {
 Answers ask(){}
}

class Results {

}

class ResultProcessor {
 Results process(Answers answers){}
}

class Database {
 void save( Results results){}
 Results fetch () {}
}

